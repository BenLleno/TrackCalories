import { Trash2 } from "lucide-react";
import { Button } from "./ui/button";

export interface Food {
  id: string;
  name: string;
  meal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface FoodItemProps {
  food: Food;
  onDelete: (id: string) => void;
}

export function FoodItem({ food, onDelete }: FoodItemProps) {
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
      <div className="flex-1">
        <div className="flex items-center gap-3 mb-1">
          <h4 className="font-medium text-gray-900">{food.name}</h4>
          <span className="text-xs px-2 py-1 bg-blue-50 text-blue-700 rounded-full">
            {food.meal}
          </span>
        </div>
        <div className="flex gap-4 text-sm text-gray-600">
          <span>{food.calories} cal</span>
          <span>P: {food.protein}g</span>
          <span>C: {food.carbs}g</span>
          <span>F: {food.fat}g</span>
        </div>
      </div>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onDelete(food.id)}
        className="text-gray-400 hover:text-red-500"
      >
        <Trash2 className="size-4" />
      </Button>
    </div>
  );
}
