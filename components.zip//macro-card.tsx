import { Progress } from "./ui/progress";

interface MacroCardProps {
  name: string;
  current: number;
  goal: number;
  unit: string;
  color: string;
}

export function MacroCard({ name, current, goal, unit, color }: MacroCardProps) {
  const percentage = Math.min((current / goal) * 100, 100);
  const remaining = Math.max(goal - current, 0);

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-medium text-gray-900">{name}</h3>
        <span className="text-sm text-gray-500">{unit}</span>
      </div>
      <div className="flex items-baseline gap-2 mb-3">
        <span className="text-3xl font-semibold" style={{ color }}>
          {current.toFixed(0)}
        </span>
        <span className="text-gray-400">/ {goal}</span>
      </div>
      <Progress value={percentage} className="h-2 mb-2" style={{ backgroundColor: `${color}20` }}>
        <div
          className="h-full transition-all rounded-full"
          style={{ width: `${percentage}%`, backgroundColor: color }}
        />
      </Progress>
      <p className="text-sm text-gray-600">
        {remaining.toFixed(0)} {unit} remaining
      </p>
    </div>
  );
}
